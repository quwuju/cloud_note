package cloud_note;

import org.apache.commons.dbcp.BasicDataSource;
import org.mybatis.spring.SqlSessionFactoryBean;
import org.mybatis.spring.mapper.MapperScannerConfigurer;
import org.springframework.jdbc.datasource.DataSourceTransactionManager;

import com.mysql.jdbc.Driver;

public class Test {
//	NumberFormatException
//	ClassNotFoundException
//	BasicDataSource
//	Driver
//	SqlSessionFactoryBean
//	MapperScannerConfigurer
//	DataSourceTransactionManager
}
